package com.google.android.gms.signin.internal;

import android.os.RemoteException;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.signin.internal.zze.zza;

public class zzb extends zza {
    public void zza(ConnectionResult connectionResult, AuthAccountResult authAccountResult) {
    }

    public void zza(Status status, GoogleSignInAccount googleSignInAccount) throws RemoteException {
    }

    public void zzbd(Status status) throws RemoteException {
    }

    public void zzbe(Status status) throws RemoteException {
    }
}
