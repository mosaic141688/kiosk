package com.google.android.gms;

import com.android.tools.fd.runtime.IncrementalChange;
import com.android.tools.fd.runtime.InstantReloadException;
import com.google.android.gms.appindexing.C0200R;

/* renamed from: com.google.android.gms.R */
public final class C0197R {
    public static volatile transient /* synthetic */ IncrementalChange $change;

    /* renamed from: com.google.android.gms.R.attr */
    public static final class attr {
        public static volatile transient /* synthetic */ IncrementalChange $change = null;
        public static final int circleCrop = 2130772152;
        public static final int imageAspectRatio = 2130772151;
        public static final int imageAspectRatioAdjust = 2130772150;

        attr(Object[] objArr, InstantReloadException instantReloadException) {
            switch (((String) objArr[0]).hashCode()) {
                case -1968665286:
                case 70686004:
                    this();
                default:
                    throw new InstantReloadException(String.format("String switch could not find '%s' with hashcode %s in %s", new Object[]{(String) objArr[0], Integer.valueOf(((String) objArr[0]).hashCode()), "com/google/android/gms/R$attr"}));
            }
        }

        public static /* synthetic */ Object access$super(attr com_google_android_gms_R_attr, String str, Object... objArr) {
            switch (str.hashCode()) {
                case -2128160755:
                    return super.toString();
                case -1600833221:
                    super.wait(((Number) objArr[0]).longValue(), ((Number) objArr[1]).intValue());
                    return null;
                case -1554832987:
                    super.finalize();
                    return null;
                case -1166127280:
                    super.notify();
                    return null;
                case -1021472056:
                    super.wait(((Number) objArr[0]).longValue());
                    return null;
                case -712101345:
                    super.notifyAll();
                    return null;
                case 201261558:
                    return super.getClass();
                case 244142972:
                    super.wait();
                    return null;
                case 1403628309:
                    return new Integer(super.hashCode());
                case 1814730534:
                    return new Boolean(super.equals(objArr[0]));
                case 2025021518:
                    return super.clone();
                default:
                    throw new InstantReloadException(String.format("String switch could not find '%s' with hashcode %s in %s", new Object[]{str, Integer.valueOf(str.hashCode()), "com/google/android/gms/R$attr"}));
            }
        }

        public attr() {
            IncrementalChange incrementalChange = $change;
            if (incrementalChange != null) {
                this((Object[]) incrementalChange.access$dispatch("init$args.([Ljava/lang/Object;)Ljava/lang/Object;", r2), null);
            }
            if (incrementalChange != null) {
                incrementalChange.access$dispatch("init$body.(Lcom/google/android/gms/R$attr;)V", this);
            }
        }
    }

    /* renamed from: com.google.android.gms.R.color */
    public static final class color {
        public static volatile transient /* synthetic */ IncrementalChange $change = null;
        public static final int common_action_bar_splitter = 2131361817;
        public static final int common_signin_btn_dark_text_default = 2131361818;
        public static final int common_signin_btn_dark_text_disabled = 2131361819;
        public static final int common_signin_btn_dark_text_focused = 2131361820;
        public static final int common_signin_btn_dark_text_pressed = 2131361821;
        public static final int common_signin_btn_default_background = 2131361822;
        public static final int common_signin_btn_light_text_default = 2131361823;
        public static final int common_signin_btn_light_text_disabled = 2131361824;
        public static final int common_signin_btn_light_text_focused = 2131361825;
        public static final int common_signin_btn_light_text_pressed = 2131361826;
        public static final int common_signin_btn_text_dark = 2131361885;
        public static final int common_signin_btn_text_light = 2131361886;

        color(Object[] objArr, InstantReloadException instantReloadException) {
            switch (((String) objArr[0]).hashCode()) {
                case -1968665286:
                case -80766290:
                    this();
                default:
                    throw new InstantReloadException(String.format("String switch could not find '%s' with hashcode %s in %s", new Object[]{(String) objArr[0], Integer.valueOf(((String) objArr[0]).hashCode()), "com/google/android/gms/R$color"}));
            }
        }

        public static /* synthetic */ Object access$super(color com_google_android_gms_R_color, String str, Object... objArr) {
            switch (str.hashCode()) {
                case -2128160755:
                    return super.toString();
                case -1600833221:
                    super.wait(((Number) objArr[0]).longValue(), ((Number) objArr[1]).intValue());
                    return null;
                case -1554832987:
                    super.finalize();
                    return null;
                case -1166127280:
                    super.notify();
                    return null;
                case -1021472056:
                    super.wait(((Number) objArr[0]).longValue());
                    return null;
                case -712101345:
                    super.notifyAll();
                    return null;
                case 201261558:
                    return super.getClass();
                case 244142972:
                    super.wait();
                    return null;
                case 1403628309:
                    return new Integer(super.hashCode());
                case 1814730534:
                    return new Boolean(super.equals(objArr[0]));
                case 2025021518:
                    return super.clone();
                default:
                    throw new InstantReloadException(String.format("String switch could not find '%s' with hashcode %s in %s", new Object[]{str, Integer.valueOf(str.hashCode()), "com/google/android/gms/R$color"}));
            }
        }

        public color() {
            IncrementalChange incrementalChange = $change;
            if (incrementalChange != null) {
                this((Object[]) incrementalChange.access$dispatch("init$args.([Ljava/lang/Object;)Ljava/lang/Object;", r2), null);
            }
            if (incrementalChange != null) {
                incrementalChange.access$dispatch("init$body.(Lcom/google/android/gms/R$color;)V", this);
            }
        }
    }

    /* renamed from: com.google.android.gms.R.drawable */
    public static final class drawable {
        public static volatile transient /* synthetic */ IncrementalChange $change = null;
        public static final int common_full_open_on_phone = 2130837580;
        public static final int common_ic_googleplayservices = 2130837581;

        drawable(Object[] objArr, InstantReloadException instantReloadException) {
            switch (((String) objArr[0]).hashCode()) {
                case -1968665286:
                case 36839265:
                    this();
                default:
                    throw new InstantReloadException(String.format("String switch could not find '%s' with hashcode %s in %s", new Object[]{(String) objArr[0], Integer.valueOf(((String) objArr[0]).hashCode()), "com/google/android/gms/R$drawable"}));
            }
        }

        public static /* synthetic */ Object access$super(drawable com_google_android_gms_R_drawable, String str, Object... objArr) {
            switch (str.hashCode()) {
                case -2128160755:
                    return super.toString();
                case -1600833221:
                    super.wait(((Number) objArr[0]).longValue(), ((Number) objArr[1]).intValue());
                    return null;
                case -1554832987:
                    super.finalize();
                    return null;
                case -1166127280:
                    super.notify();
                    return null;
                case -1021472056:
                    super.wait(((Number) objArr[0]).longValue());
                    return null;
                case -712101345:
                    super.notifyAll();
                    return null;
                case 201261558:
                    return super.getClass();
                case 244142972:
                    super.wait();
                    return null;
                case 1403628309:
                    return new Integer(super.hashCode());
                case 1814730534:
                    return new Boolean(super.equals(objArr[0]));
                case 2025021518:
                    return super.clone();
                default:
                    throw new InstantReloadException(String.format("String switch could not find '%s' with hashcode %s in %s", new Object[]{str, Integer.valueOf(str.hashCode()), "com/google/android/gms/R$drawable"}));
            }
        }

        public drawable() {
            IncrementalChange incrementalChange = $change;
            if (incrementalChange != null) {
                this((Object[]) incrementalChange.access$dispatch("init$args.([Ljava/lang/Object;)Ljava/lang/Object;", r2), null);
            }
            if (incrementalChange != null) {
                incrementalChange.access$dispatch("init$body.(Lcom/google/android/gms/R$drawable;)V", this);
            }
        }
    }

    /* renamed from: com.google.android.gms.R.id */
    public static final class id {
        public static volatile transient /* synthetic */ IncrementalChange $change = null;
        public static final int adjust_height = 2131427357;
        public static final int adjust_width = 2131427358;
        public static final int none = 2131427342;
        public static final int normal = 2131427338;
        public static final int wrap_content = 2131427353;

        id(Object[] objArr, InstantReloadException instantReloadException) {
            switch (((String) objArr[0]).hashCode()) {
                case -1968665286:
                case -650395042:
                    this();
                default:
                    throw new InstantReloadException(String.format("String switch could not find '%s' with hashcode %s in %s", new Object[]{(String) objArr[0], Integer.valueOf(((String) objArr[0]).hashCode()), "com/google/android/gms/R$id"}));
            }
        }

        public static /* synthetic */ Object access$super(id idVar, String str, Object... objArr) {
            switch (str.hashCode()) {
                case -2128160755:
                    return super.toString();
                case -1600833221:
                    super.wait(((Number) objArr[0]).longValue(), ((Number) objArr[1]).intValue());
                    return null;
                case -1554832987:
                    super.finalize();
                    return null;
                case -1166127280:
                    super.notify();
                    return null;
                case -1021472056:
                    super.wait(((Number) objArr[0]).longValue());
                    return null;
                case -712101345:
                    super.notifyAll();
                    return null;
                case 201261558:
                    return super.getClass();
                case 244142972:
                    super.wait();
                    return null;
                case 1403628309:
                    return new Integer(super.hashCode());
                case 1814730534:
                    return new Boolean(super.equals(objArr[0]));
                case 2025021518:
                    return super.clone();
                default:
                    throw new InstantReloadException(String.format("String switch could not find '%s' with hashcode %s in %s", new Object[]{str, Integer.valueOf(str.hashCode()), "com/google/android/gms/R$id"}));
            }
        }

        public id() {
            IncrementalChange incrementalChange = $change;
            if (incrementalChange != null) {
                this((Object[]) incrementalChange.access$dispatch("init$args.([Ljava/lang/Object;)Ljava/lang/Object;", r2), null);
            }
            if (incrementalChange != null) {
                incrementalChange.access$dispatch("init$body.(Lcom/google/android/gms/R$id;)V", this);
            }
        }
    }

    /* renamed from: com.google.android.gms.R.integer */
    public static final class integer {
        public static volatile transient /* synthetic */ IncrementalChange $change = null;
        public static final int google_play_services_version = 2131492867;

        integer(Object[] objArr, InstantReloadException instantReloadException) {
            switch (((String) objArr[0]).hashCode()) {
                case -1968665286:
                case 640189961:
                    this();
                default:
                    throw new InstantReloadException(String.format("String switch could not find '%s' with hashcode %s in %s", new Object[]{(String) objArr[0], Integer.valueOf(((String) objArr[0]).hashCode()), "com/google/android/gms/R$integer"}));
            }
        }

        public static /* synthetic */ Object access$super(integer com_google_android_gms_R_integer, String str, Object... objArr) {
            switch (str.hashCode()) {
                case -2128160755:
                    return super.toString();
                case -1600833221:
                    super.wait(((Number) objArr[0]).longValue(), ((Number) objArr[1]).intValue());
                    return null;
                case -1554832987:
                    super.finalize();
                    return null;
                case -1166127280:
                    super.notify();
                    return null;
                case -1021472056:
                    super.wait(((Number) objArr[0]).longValue());
                    return null;
                case -712101345:
                    super.notifyAll();
                    return null;
                case 201261558:
                    return super.getClass();
                case 244142972:
                    super.wait();
                    return null;
                case 1403628309:
                    return new Integer(super.hashCode());
                case 1814730534:
                    return new Boolean(super.equals(objArr[0]));
                case 2025021518:
                    return super.clone();
                default:
                    throw new InstantReloadException(String.format("String switch could not find '%s' with hashcode %s in %s", new Object[]{str, Integer.valueOf(str.hashCode()), "com/google/android/gms/R$integer"}));
            }
        }

        public integer() {
            IncrementalChange incrementalChange = $change;
            if (incrementalChange != null) {
                this((Object[]) incrementalChange.access$dispatch("init$args.([Ljava/lang/Object;)Ljava/lang/Object;", r2), null);
            }
            if (incrementalChange != null) {
                incrementalChange.access$dispatch("init$body.(Lcom/google/android/gms/R$integer;)V", this);
            }
        }
    }

    /* renamed from: com.google.android.gms.R.raw */
    public static final class raw {
        public static volatile transient /* synthetic */ IncrementalChange $change;

        raw(Object[] objArr, InstantReloadException instantReloadException) {
            switch (((String) objArr[0]).hashCode()) {
                case -1968665286:
                case 691894771:
                    this();
                default:
                    throw new InstantReloadException(String.format("String switch could not find '%s' with hashcode %s in %s", new Object[]{(String) objArr[0], Integer.valueOf(((String) objArr[0]).hashCode()), "com/google/android/gms/R$raw"}));
            }
        }

        public static /* synthetic */ Object access$super(raw com_google_android_gms_R_raw, String str, Object... objArr) {
            switch (str.hashCode()) {
                case -2128160755:
                    return super.toString();
                case -1600833221:
                    super.wait(((Number) objArr[0]).longValue(), ((Number) objArr[1]).intValue());
                    return null;
                case -1554832987:
                    super.finalize();
                    return null;
                case -1166127280:
                    super.notify();
                    return null;
                case -1021472056:
                    super.wait(((Number) objArr[0]).longValue());
                    return null;
                case -712101345:
                    super.notifyAll();
                    return null;
                case 201261558:
                    return super.getClass();
                case 244142972:
                    super.wait();
                    return null;
                case 1403628309:
                    return new Integer(super.hashCode());
                case 1814730534:
                    return new Boolean(super.equals(objArr[0]));
                case 2025021518:
                    return super.clone();
                default:
                    throw new InstantReloadException(String.format("String switch could not find '%s' with hashcode %s in %s", new Object[]{str, Integer.valueOf(str.hashCode()), "com/google/android/gms/R$raw"}));
            }
        }

        public raw() {
            IncrementalChange incrementalChange = $change;
            if (incrementalChange != null) {
                this((Object[]) incrementalChange.access$dispatch("init$args.([Ljava/lang/Object;)Ljava/lang/Object;", r2), null);
            }
            if (incrementalChange != null) {
                incrementalChange.access$dispatch("init$body.(Lcom/google/android/gms/R$raw;)V", this);
            }
        }
    }

    /* renamed from: com.google.android.gms.R.string */
    public static final class string {
        public static volatile transient /* synthetic */ IncrementalChange $change = null;
        public static final int auth_google_play_services_client_facebook_display_name = 2131099711;
        public static final int auth_google_play_services_client_google_display_name = 2131099712;
        public static final int common_android_wear_notification_needs_update_text = 2131099667;
        public static final int common_android_wear_update_text = 2131099668;
        public static final int common_android_wear_update_title = 2131099669;
        public static final int common_google_play_services_api_unavailable_text = 2131099670;
        public static final int common_google_play_services_enable_button = 2131099671;
        public static final int common_google_play_services_enable_text = 2131099672;
        public static final int common_google_play_services_enable_title = 2131099673;
        public static final int common_google_play_services_error_notification_requested_by_msg = 2131099674;
        public static final int common_google_play_services_install_button = 2131099675;
        public static final int common_google_play_services_install_text_phone = 2131099676;
        public static final int common_google_play_services_install_text_tablet = 2131099677;
        public static final int common_google_play_services_install_title = 2131099678;
        public static final int common_google_play_services_invalid_account_text = 2131099679;
        public static final int common_google_play_services_invalid_account_title = 2131099680;
        public static final int common_google_play_services_needs_enabling_title = 2131099681;
        public static final int common_google_play_services_network_error_text = 2131099682;
        public static final int common_google_play_services_network_error_title = 2131099683;
        public static final int common_google_play_services_notification_needs_update_title = 2131099684;
        public static final int common_google_play_services_notification_ticker = 2131099685;
        public static final int common_google_play_services_sign_in_failed_text = 2131099686;
        public static final int common_google_play_services_sign_in_failed_title = 2131099687;
        public static final int common_google_play_services_unknown_issue = 2131099688;
        public static final int common_google_play_services_unsupported_text = 2131099689;
        public static final int common_google_play_services_unsupported_title = 2131099690;
        public static final int common_google_play_services_update_button = 2131099691;
        public static final int common_google_play_services_update_text = 2131099692;
        public static final int common_google_play_services_update_title = 2131099693;
        public static final int common_google_play_services_updating_text = 2131099694;
        public static final int common_google_play_services_updating_title = 2131099695;
        public static final int common_open_on_phone = 2131099696;

        string(Object[] objArr, InstantReloadException instantReloadException) {
            switch (((String) objArr[0]).hashCode()) {
                case -1968665286:
                case -1025168300:
                    this();
                default:
                    throw new InstantReloadException(String.format("String switch could not find '%s' with hashcode %s in %s", new Object[]{(String) objArr[0], Integer.valueOf(((String) objArr[0]).hashCode()), "com/google/android/gms/R$string"}));
            }
        }

        public static /* synthetic */ Object access$super(string com_google_android_gms_R_string, String str, Object... objArr) {
            switch (str.hashCode()) {
                case -2128160755:
                    return super.toString();
                case -1600833221:
                    super.wait(((Number) objArr[0]).longValue(), ((Number) objArr[1]).intValue());
                    return null;
                case -1554832987:
                    super.finalize();
                    return null;
                case -1166127280:
                    super.notify();
                    return null;
                case -1021472056:
                    super.wait(((Number) objArr[0]).longValue());
                    return null;
                case -712101345:
                    super.notifyAll();
                    return null;
                case 201261558:
                    return super.getClass();
                case 244142972:
                    super.wait();
                    return null;
                case 1403628309:
                    return new Integer(super.hashCode());
                case 1814730534:
                    return new Boolean(super.equals(objArr[0]));
                case 2025021518:
                    return super.clone();
                default:
                    throw new InstantReloadException(String.format("String switch could not find '%s' with hashcode %s in %s", new Object[]{str, Integer.valueOf(str.hashCode()), "com/google/android/gms/R$string"}));
            }
        }

        public string() {
            IncrementalChange incrementalChange = $change;
            if (incrementalChange != null) {
                this((Object[]) incrementalChange.access$dispatch("init$args.([Ljava/lang/Object;)Ljava/lang/Object;", r2), null);
            }
            if (incrementalChange != null) {
                incrementalChange.access$dispatch("init$body.(Lcom/google/android/gms/R$string;)V", this);
            }
        }
    }

    /* renamed from: com.google.android.gms.R.style */
    public static final class style {
        public static volatile transient /* synthetic */ IncrementalChange $change;

        style(Object[] objArr, InstantReloadException instantReloadException) {
            switch (((String) objArr[0]).hashCode()) {
                case -1968665286:
                case -256396804:
                    this();
                default:
                    throw new InstantReloadException(String.format("String switch could not find '%s' with hashcode %s in %s", new Object[]{(String) objArr[0], Integer.valueOf(((String) objArr[0]).hashCode()), "com/google/android/gms/R$style"}));
            }
        }

        public static /* synthetic */ Object access$super(style com_google_android_gms_R_style, String str, Object... objArr) {
            switch (str.hashCode()) {
                case -2128160755:
                    return super.toString();
                case -1600833221:
                    super.wait(((Number) objArr[0]).longValue(), ((Number) objArr[1]).intValue());
                    return null;
                case -1554832987:
                    super.finalize();
                    return null;
                case -1166127280:
                    super.notify();
                    return null;
                case -1021472056:
                    super.wait(((Number) objArr[0]).longValue());
                    return null;
                case -712101345:
                    super.notifyAll();
                    return null;
                case 201261558:
                    return super.getClass();
                case 244142972:
                    super.wait();
                    return null;
                case 1403628309:
                    return new Integer(super.hashCode());
                case 1814730534:
                    return new Boolean(super.equals(objArr[0]));
                case 2025021518:
                    return super.clone();
                default:
                    throw new InstantReloadException(String.format("String switch could not find '%s' with hashcode %s in %s", new Object[]{str, Integer.valueOf(str.hashCode()), "com/google/android/gms/R$style"}));
            }
        }

        public style() {
            IncrementalChange incrementalChange = $change;
            if (incrementalChange != null) {
                this((Object[]) incrementalChange.access$dispatch("init$args.([Ljava/lang/Object;)Ljava/lang/Object;", r2), null);
            }
            if (incrementalChange != null) {
                incrementalChange.access$dispatch("init$body.(Lcom/google/android/gms/R$style;)V", this);
            }
        }
    }

    /* renamed from: com.google.android.gms.R.styleable */
    public static final class styleable {
        public static volatile transient /* synthetic */ IncrementalChange $change = null;
        public static final int[] LoadingImageView;
        public static final int LoadingImageView_circleCrop = 2;
        public static final int LoadingImageView_imageAspectRatio = 1;
        public static final int LoadingImageView_imageAspectRatioAdjust = 0;

        styleable(Object[] objArr, InstantReloadException instantReloadException) {
            switch (((String) objArr[0]).hashCode()) {
                case -1968665286:
                case -1432795178:
                    this();
                default:
                    throw new InstantReloadException(String.format("String switch could not find '%s' with hashcode %s in %s", new Object[]{(String) objArr[0], Integer.valueOf(((String) objArr[0]).hashCode()), "com/google/android/gms/R$styleable"}));
            }
        }

        public static /* synthetic */ Object access$super(styleable com_google_android_gms_R_styleable, String str, Object... objArr) {
            switch (str.hashCode()) {
                case -2128160755:
                    return super.toString();
                case -1600833221:
                    super.wait(((Number) objArr[0]).longValue(), ((Number) objArr[LoadingImageView_imageAspectRatio]).intValue());
                    return null;
                case -1554832987:
                    super.finalize();
                    return null;
                case -1166127280:
                    super.notify();
                    return null;
                case -1021472056:
                    super.wait(((Number) objArr[0]).longValue());
                    return null;
                case -712101345:
                    super.notifyAll();
                    return null;
                case 201261558:
                    return super.getClass();
                case 244142972:
                    super.wait();
                    return null;
                case 1403628309:
                    return new Integer(super.hashCode());
                case 1814730534:
                    return new Boolean(super.equals(objArr[0]));
                case 2025021518:
                    return super.clone();
                default:
                    throw new InstantReloadException(String.format("String switch could not find '%s' with hashcode %s in %s", new Object[]{str, Integer.valueOf(str.hashCode()), "com/google/android/gms/R$styleable"}));
            }
        }

        public styleable() {
            IncrementalChange incrementalChange = $change;
            if (incrementalChange != null) {
                Object[] objArr = new Object[LoadingImageView_imageAspectRatio];
                objArr[0] = objArr;
                this((Object[]) incrementalChange.access$dispatch("init$args.([Ljava/lang/Object;)Ljava/lang/Object;", objArr), null);
            }
            if (incrementalChange != null) {
                objArr = new Object[LoadingImageView_imageAspectRatio];
                objArr[0] = this;
                incrementalChange.access$dispatch("init$body.(Lcom/google/android/gms/R$styleable;)V", objArr);
            }
        }

        static {
            LoadingImageView = new int[]{C0200R.attr.imageAspectRatioAdjust, C0200R.attr.imageAspectRatio, C0200R.attr.circleCrop};
        }
    }

    C0197R(Object[] objArr, InstantReloadException instantReloadException) {
        switch (((String) objArr[0]).hashCode()) {
            case -1968665286:
            case -1376322961:
                this();
            default:
                throw new InstantReloadException(String.format("String switch could not find '%s' with hashcode %s in %s", new Object[]{(String) objArr[0], Integer.valueOf(((String) objArr[0]).hashCode()), "com/google/android/gms/R"}));
        }
    }

    public static /* synthetic */ Object access$super(C0197R c0197r, String str, Object... objArr) {
        switch (str.hashCode()) {
            case -2128160755:
                return super.toString();
            case -1600833221:
                super.wait(((Number) objArr[0]).longValue(), ((Number) objArr[1]).intValue());
                return null;
            case -1554832987:
                super.finalize();
                return null;
            case -1166127280:
                super.notify();
                return null;
            case -1021472056:
                super.wait(((Number) objArr[0]).longValue());
                return null;
            case -712101345:
                super.notifyAll();
                return null;
            case 201261558:
                return super.getClass();
            case 244142972:
                super.wait();
                return null;
            case 1403628309:
                return new Integer(super.hashCode());
            case 1814730534:
                return new Boolean(super.equals(objArr[0]));
            case 2025021518:
                return super.clone();
            default:
                throw new InstantReloadException(String.format("String switch could not find '%s' with hashcode %s in %s", new Object[]{str, Integer.valueOf(str.hashCode()), "com/google/android/gms/R"}));
        }
    }

    public C0197R() {
        IncrementalChange incrementalChange = $change;
        if (incrementalChange != null) {
            this((Object[]) incrementalChange.access$dispatch("init$args.([Ljava/lang/Object;)Ljava/lang/Object;", r2), null);
        }
        if (incrementalChange != null) {
            incrementalChange.access$dispatch("init$body.(Lcom/google/android/gms/R;)V", this);
        }
    }
}
