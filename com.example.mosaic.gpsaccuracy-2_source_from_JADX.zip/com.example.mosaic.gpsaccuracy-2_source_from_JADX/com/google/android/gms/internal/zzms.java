package com.google.android.gms.internal;

public final class zzms {
    public static boolean zzcc(int i) {
        return i >= 3200000;
    }
}
