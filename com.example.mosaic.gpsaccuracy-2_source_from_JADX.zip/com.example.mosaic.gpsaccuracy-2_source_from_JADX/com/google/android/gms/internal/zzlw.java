package com.google.android.gms.internal;

import android.os.RemoteException;
import com.google.android.gms.internal.zzmc.zza;

public class zzlw extends zza {
    public void zzbN(int i) throws RemoteException {
    }
}
