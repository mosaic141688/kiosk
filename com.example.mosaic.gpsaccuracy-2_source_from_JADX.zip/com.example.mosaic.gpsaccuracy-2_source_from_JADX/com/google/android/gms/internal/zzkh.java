package com.google.android.gms.internal;

import android.os.RemoteException;
import com.google.android.gms.auth.api.proxy.ProxyResponse;
import com.google.android.gms.internal.zzkj.zza;

public class zzkh extends zza {
    public void zza(ProxyResponse proxyResponse) throws RemoteException {
        throw new UnsupportedOperationException();
    }
}
