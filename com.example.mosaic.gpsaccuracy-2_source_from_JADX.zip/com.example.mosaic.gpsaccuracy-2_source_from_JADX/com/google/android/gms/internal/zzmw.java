package com.google.android.gms.internal;

public class zzmw {
    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static int zza(byte[] r6, int r7, int r8, int r9) {
        /*
        r5 = 461845907; // 0x1b873593 float:2.2368498E-22 double:2.281821963E-315;
        r4 = -862048943; // 0xffffffffcc9e2d51 float:-8.2930312E7 double:NaN;
        r0 = r8 & -4;
        r2 = r7 + r0;
        r1 = r9;
    L_0x000b:
        if (r7 >= r2) goto L_0x0040;
    L_0x000d:
        r0 = r6[r7];
        r0 = r0 & 255;
        r3 = r7 + 1;
        r3 = r6[r3];
        r3 = r3 & 255;
        r3 = r3 << 8;
        r0 = r0 | r3;
        r3 = r7 + 2;
        r3 = r6[r3];
        r3 = r3 & 255;
        r3 = r3 << 16;
        r0 = r0 | r3;
        r3 = r7 + 3;
        r3 = r6[r3];
        r3 = r3 << 24;
        r0 = r0 | r3;
        r0 = r0 * r4;
        r3 = r0 << 15;
        r0 = r0 >>> 17;
        r0 = r0 | r3;
        r0 = r0 * r5;
        r0 = r0 ^ r1;
        r1 = r0 << 13;
        r0 = r0 >>> 19;
        r0 = r0 | r1;
        r0 = r0 * 5;
        r1 = -430675100; // 0xffffffffe6546b64 float:-2.5078068E23 double:NaN;
        r1 = r1 + r0;
        r7 = r7 + 4;
        goto L_0x000b;
    L_0x0040:
        r0 = 0;
        r3 = r8 & 3;
        switch(r3) {
            case 1: goto L_0x006b;
            case 2: goto L_0x0062;
            case 3: goto L_0x005a;
            default: goto L_0x0046;
        };
    L_0x0046:
        r0 = r1;
    L_0x0047:
        r0 = r0 ^ r8;
        r1 = r0 >>> 16;
        r0 = r0 ^ r1;
        r1 = -2048144789; // 0xffffffff85ebca6b float:-2.217365E-35 double:NaN;
        r0 = r0 * r1;
        r1 = r0 >>> 13;
        r0 = r0 ^ r1;
        r1 = -1028477387; // 0xffffffffc2b2ae35 float:-89.34025 double:NaN;
        r0 = r0 * r1;
        r1 = r0 >>> 16;
        r0 = r0 ^ r1;
        return r0;
    L_0x005a:
        r0 = r2 + 2;
        r0 = r6[r0];
        r0 = r0 & 255;
        r0 = r0 << 16;
    L_0x0062:
        r3 = r2 + 1;
        r3 = r6[r3];
        r3 = r3 & 255;
        r3 = r3 << 8;
        r0 = r0 | r3;
    L_0x006b:
        r2 = r6[r2];
        r2 = r2 & 255;
        r0 = r0 | r2;
        r0 = r0 * r4;
        r2 = r0 << 15;
        r0 = r0 >>> 17;
        r0 = r0 | r2;
        r0 = r0 * r5;
        r0 = r0 ^ r1;
        goto L_0x0047;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzmw.zza(byte[], int, int, int):int");
    }
}
