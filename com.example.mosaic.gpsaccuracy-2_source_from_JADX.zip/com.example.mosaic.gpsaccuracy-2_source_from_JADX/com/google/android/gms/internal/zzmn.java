package com.google.android.gms.internal;

public interface zzmn {
    long currentTimeMillis();

    long elapsedRealtime();

    long nanoTime();
}
