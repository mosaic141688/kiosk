package com.google.android.gms.internal;

import android.util.Base64;

public final class zzmk {
    public static String zzi(byte[] bArr) {
        return bArr == null ? null : Base64.encodeToString(bArr, 0);
    }

    public static String zzj(byte[] bArr) {
        return bArr == null ? null : Base64.encodeToString(bArr, 10);
    }
}
