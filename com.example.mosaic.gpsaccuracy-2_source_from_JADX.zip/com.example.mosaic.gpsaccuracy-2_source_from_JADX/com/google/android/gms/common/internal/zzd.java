package com.google.android.gms.common.internal;

public class zzd {
    public static final boolean zzaeK;

    static {
        zzaeK = zzjA();
    }

    private static final boolean zzjA() {
        return false;
    }
}
