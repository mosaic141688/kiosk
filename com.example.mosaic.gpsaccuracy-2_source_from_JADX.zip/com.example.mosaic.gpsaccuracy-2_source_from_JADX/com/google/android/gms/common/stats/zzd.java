package com.google.android.gms.common.stats;

import android.content.ComponentName;
import com.google.android.gms.common.GooglePlayServicesUtil;

public final class zzd {
    public static int LOG_LEVEL_OFF;
    public static final ComponentName zzahN;
    public static int zzahO;
    public static int zzahP;
    public static int zzahQ;
    public static int zzahR;
    public static int zzahS;
    public static int zzahT;
    public static int zzahU;

    static {
        zzahN = new ComponentName(GooglePlayServicesUtil.GOOGLE_PLAY_SERVICES_PACKAGE, "com.google.android.gms.common.stats.GmsCoreStatsService");
        LOG_LEVEL_OFF = 0;
        zzahO = 1;
        zzahP = 2;
        zzahQ = 4;
        zzahR = 8;
        zzahS = 16;
        zzahT = 32;
        zzahU = 1;
    }
}
