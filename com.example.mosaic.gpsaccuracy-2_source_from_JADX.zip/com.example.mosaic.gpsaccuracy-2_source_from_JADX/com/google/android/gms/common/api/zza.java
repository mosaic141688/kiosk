package com.google.android.gms.common.api;

import android.app.Activity;
import java.util.Map;
import java.util.WeakHashMap;

public abstract class zza {
    private static final Map<Activity, zza> zzaaZ;
    private static final Object zzpy;

    static {
        zzaaZ = new WeakHashMap();
        zzpy = new Object();
    }

    public abstract void remove(int i);
}
