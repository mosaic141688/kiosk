package com.google.android.gms.dynamic;

public interface zzf<T extends LifecycleDelegate> {
    void zza(T t);
}
