package com.google.android.gms.appdatasearch;

import com.google.android.gms.appdatasearch.GetRecentContextCall.Request;
import com.google.android.gms.appdatasearch.GetRecentContextCall.Response;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;

public interface zzk {
    PendingResult<Response> zza(GoogleApiClient googleApiClient, Request request);
}
