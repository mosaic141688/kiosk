package com.google.android.gms.auth.api.signin;

import com.google.android.gms.common.api.Api.ApiOptions.HasOptions;

public class zzg implements HasOptions {
}
