package com.google.android.gms.auth.api.consent;

import android.accounts.Account;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.auth.firstparty.shared.ScopeDetail;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.internal.safeparcel.zza;

public class zzb implements Creator<GetConsentIntentRequest> {
    static void zza(GetConsentIntentRequest getConsentIntentRequest, Parcel parcel, int i) {
        int zzaq = com.google.android.gms.common.internal.safeparcel.zzb.zzaq(parcel);
        com.google.android.gms.common.internal.safeparcel.zzb.zzc(parcel, 1, getConsentIntentRequest.getVersionCode());
        com.google.android.gms.common.internal.safeparcel.zzb.zza(parcel, 2, getConsentIntentRequest.getCallingPackage(), false);
        com.google.android.gms.common.internal.safeparcel.zzb.zzc(parcel, 3, getConsentIntentRequest.getCallingUid());
        com.google.android.gms.common.internal.safeparcel.zzb.zza(parcel, 4, getConsentIntentRequest.zzlF(), false);
        com.google.android.gms.common.internal.safeparcel.zzb.zza(parcel, 5, getConsentIntentRequest.getAccount(), i, false);
        com.google.android.gms.common.internal.safeparcel.zzb.zza(parcel, 6, getConsentIntentRequest.zzSe, i, false);
        com.google.android.gms.common.internal.safeparcel.zzb.zza(parcel, 7, getConsentIntentRequest.zzlG());
        com.google.android.gms.common.internal.safeparcel.zzb.zzc(parcel, 8, getConsentIntentRequest.zzlH());
        com.google.android.gms.common.internal.safeparcel.zzb.zzI(parcel, zzaq);
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return zzD(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return zzau(x0);
    }

    public GetConsentIntentRequest zzD(Parcel parcel) {
        ScopeDetail[] scopeDetailArr = null;
        int i = 0;
        int zzap = zza.zzap(parcel);
        boolean z = false;
        Account account = null;
        String str = null;
        int i2 = 0;
        String str2 = null;
        int i3 = 0;
        while (parcel.dataPosition() < zzap) {
            int zzao = zza.zzao(parcel);
            switch (zza.zzbM(zzao)) {
                case ConnectionResult.SERVICE_MISSING /*1*/:
                    i3 = zza.zzg(parcel, zzao);
                    break;
                case ConnectionResult.SERVICE_VERSION_UPDATE_REQUIRED /*2*/:
                    str2 = zza.zzp(parcel, zzao);
                    break;
                case ConnectionResult.SERVICE_DISABLED /*3*/:
                    i2 = zza.zzg(parcel, zzao);
                    break;
                case ConnectionResult.SIGN_IN_REQUIRED /*4*/:
                    str = zza.zzp(parcel, zzao);
                    break;
                case ConnectionResult.INVALID_ACCOUNT /*5*/:
                    account = (Account) zza.zza(parcel, zzao, Account.CREATOR);
                    break;
                case ConnectionResult.RESOLUTION_REQUIRED /*6*/:
                    scopeDetailArr = (ScopeDetail[]) zza.zzb(parcel, zzao, ScopeDetail.CREATOR);
                    break;
                case ConnectionResult.NETWORK_ERROR /*7*/:
                    z = zza.zzc(parcel, zzao);
                    break;
                case ConnectionResult.INTERNAL_ERROR /*8*/:
                    i = zza.zzg(parcel, zzao);
                    break;
                default:
                    zza.zzb(parcel, zzao);
                    break;
            }
        }
        if (parcel.dataPosition() == zzap) {
            return new GetConsentIntentRequest(i3, str2, i2, str, account, scopeDetailArr, z, i);
        }
        throw new zza.zza("Overread allowed size end=" + zzap, parcel);
    }

    public GetConsentIntentRequest[] zzau(int i) {
        return new GetConsentIntentRequest[i];
    }
}
