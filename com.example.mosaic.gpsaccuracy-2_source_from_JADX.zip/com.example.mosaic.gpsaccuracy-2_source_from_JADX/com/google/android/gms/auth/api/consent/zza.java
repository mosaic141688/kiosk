package com.google.android.gms.auth.api.consent;

public interface zza {
}
