package com.google.android.gms.auth.api.credentials.internal;

import com.google.android.gms.auth.api.credentials.Credential;
import com.google.android.gms.common.api.Status;

public class zza extends com.google.android.gms.auth.api.credentials.internal.zzg.zza {
    public void zza(Status status, Credential credential) {
        throw new UnsupportedOperationException();
    }

    public void zzg(Status status) {
        throw new UnsupportedOperationException();
    }
}
