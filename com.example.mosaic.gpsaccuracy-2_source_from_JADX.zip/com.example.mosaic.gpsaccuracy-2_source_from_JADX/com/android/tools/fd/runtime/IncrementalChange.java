package com.android.tools.fd.runtime;

public interface IncrementalChange {
    Object access$dispatch(String str, Object... objArr);
}
