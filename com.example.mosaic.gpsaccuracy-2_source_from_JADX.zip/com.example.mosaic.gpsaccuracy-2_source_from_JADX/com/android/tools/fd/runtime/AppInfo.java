package com.android.tools.fd.runtime;

import com.example.mosaic.gpsaccuracy.BuildConfig;

public class AppInfo {
    public static String applicationClass;
    public static String applicationId;
    public static long token;
    public static boolean usingApkSplits;

    static {
        applicationId = BuildConfig.APPLICATION_ID;
        applicationClass = null;
        token = 3182397390208997002L;
        usingApkSplits = false;
    }
}
