package com.android.tools.fd.runtime;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.os.Build.VERSION;
import android.os.Handler;
import android.os.Looper;
import android.util.ArrayMap;
import android.util.Log;
import android.widget.Toast;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;

public class Restarter {

    /* renamed from: com.android.tools.fd.runtime.Restarter.1 */
    static class C01811 implements Runnable {
        final /* synthetic */ Activity val$activity;

        C01811(Activity activity) {
            this.val$activity = activity;
        }

        public void run() {
            if (Log.isLoggable(BootstrapApplication.LOG_TAG, 2)) {
                Log.v(BootstrapApplication.LOG_TAG, "Resources updated: notify activities");
            }
            Restarter.updateActivity(this.val$activity);
        }
    }

    /* renamed from: com.android.tools.fd.runtime.Restarter.2 */
    static class C01822 implements Runnable {
        final /* synthetic */ Activity val$activity;
        final /* synthetic */ String val$text;

        C01822(Activity activity, String str) {
            this.val$activity = activity;
            this.val$text = str;
        }

        public void run() {
            try {
                Context context = this.val$activity.getApplicationContext();
                if (!(context instanceof ContextWrapper) || ((ContextWrapper) context).getBaseContext() != null) {
                    int duration = 0;
                    if (this.val$text.length() >= 60 || this.val$text.indexOf(10) != -1) {
                        duration = 1;
                    }
                    Toast.makeText(this.val$activity, this.val$text, duration).show();
                } else if (Log.isLoggable(BootstrapApplication.LOG_TAG, 5)) {
                    Log.w(BootstrapApplication.LOG_TAG, "Couldn't show toast: no base context");
                }
            } catch (Throwable e) {
                if (Log.isLoggable(BootstrapApplication.LOG_TAG, 5)) {
                    Log.w(BootstrapApplication.LOG_TAG, "Couldn't show toast", e);
                }
            }
        }
    }

    /* renamed from: com.android.tools.fd.runtime.Restarter.3 */
    static class C01833 implements Runnable {
        final /* synthetic */ Context val$context;
        final /* synthetic */ String val$message;
        final /* synthetic */ int val$remainingAttempts;

        C01833(Context context, String str, int i) {
            this.val$context = context;
            this.val$message = str;
            this.val$remainingAttempts = i;
        }

        public void run() {
            Activity activity = Restarter.getForegroundActivity(this.val$context);
            if (activity != null) {
                Restarter.showToast(activity, this.val$message);
            } else if (this.val$remainingAttempts > 0) {
                Restarter.showToastWhenPossible(this.val$context, this.val$message, this.val$remainingAttempts - 1);
            }
        }
    }

    public static void restartActivityOnUiThread(Activity activity) {
        activity.runOnUiThread(new C01811(activity));
    }

    private static void restartActivity(Activity activity) {
        if (Log.isLoggable(BootstrapApplication.LOG_TAG, 2)) {
            Log.v(BootstrapApplication.LOG_TAG, "About to restart " + activity.getClass().getSimpleName());
        }
        while (activity.getParent() != null) {
            if (Log.isLoggable(BootstrapApplication.LOG_TAG, 2)) {
                Log.v(BootstrapApplication.LOG_TAG, activity.getClass().getSimpleName() + " is not a top level activity; restarting " + activity.getParent().getClass().getSimpleName() + " instead");
            }
            activity = activity.getParent();
        }
        activity.recreate();
    }

    public static void restartApp(Context appContext, Collection<Activity> knownActivities, boolean toast) {
        if (!knownActivities.isEmpty()) {
            Context foreground = getForegroundActivity(appContext);
            if (foreground != null) {
                if (toast) {
                    showToast(foreground, "Restarting app to apply incompatible changes");
                }
                if (Log.isLoggable(BootstrapApplication.LOG_TAG, 2)) {
                    Log.v(BootstrapApplication.LOG_TAG, "RESTARTING APP");
                }
                Context context = foreground;
                ((AlarmManager) context.getSystemService(NotificationCompatApi24.CATEGORY_ALARM)).set(1, System.currentTimeMillis() + 100, PendingIntent.getActivity(context, 0, new Intent(context, foreground.getClass()), 268435456));
                if (Log.isLoggable(BootstrapApplication.LOG_TAG, 2)) {
                    Log.v(BootstrapApplication.LOG_TAG, "Scheduling activity " + foreground + " to start after exiting process");
                }
            } else {
                showToast((Activity) knownActivities.iterator().next(), "Unable to restart app");
                if (Log.isLoggable(BootstrapApplication.LOG_TAG, 2)) {
                    Log.v(BootstrapApplication.LOG_TAG, "Couldn't find any foreground activities to restart for resource refresh");
                }
            }
            System.exit(0);
        }
    }

    static void showToast(Activity activity, String text) {
        if (Log.isLoggable(BootstrapApplication.LOG_TAG, 2)) {
            Log.v(BootstrapApplication.LOG_TAG, "About to show toast for activity " + activity + ": " + text);
        }
        activity.runOnUiThread(new C01822(activity, text));
    }

    public static Activity getForegroundActivity(Context context) {
        List<Activity> list = getActivities(context, true);
        return list.isEmpty() ? null : (Activity) list.get(0);
    }

    public static List<Activity> getActivities(Context context, boolean foregroundOnly) {
        List<Activity> list = new ArrayList();
        try {
            Class activityThreadClass = Class.forName("android.app.ActivityThread");
            Object activityThread = MonkeyPatcher.getActivityThread(context, activityThreadClass);
            Field activitiesField = activityThreadClass.getDeclaredField("mActivities");
            activitiesField.setAccessible(true);
            Object collection = activitiesField.get(activityThread);
            Collection c;
            if (collection instanceof HashMap) {
                c = ((HashMap) collection).values();
            } else {
                if (VERSION.SDK_INT >= 19 && (collection instanceof ArrayMap)) {
                    c = ((ArrayMap) collection).values();
                }
                return list;
            }
            for (Object activityRecord : c) {
                Class activityRecordClass = activityRecord.getClass();
                if (foregroundOnly) {
                    Field pausedField = activityRecordClass.getDeclaredField("paused");
                    pausedField.setAccessible(true);
                    if (pausedField.getBoolean(activityRecord)) {
                    }
                }
                Field activityField = activityRecordClass.getDeclaredField("activity");
                activityField.setAccessible(true);
                Activity activity = (Activity) activityField.get(activityRecord);
                if (activity != null) {
                    list.add(activity);
                }
            }
        } catch (Throwable th) {
        }
        return list;
    }

    private static void updateActivity(Activity activity) {
        restartActivity(activity);
    }

    public static void showToastWhenPossible(Context context, String message) {
        Activity activity = getForegroundActivity(context);
        if (activity != null) {
            showToast(activity, message);
        } else {
            showToastWhenPossible(context, message, 10);
        }
    }

    private static void showToastWhenPossible(Context context, String message, int remainingAttempts) {
        new Handler(Looper.getMainLooper()).postDelayed(new C01833(context, message, remainingAttempts), 1000);
    }
}
