package com.android.tools.fd.runtime;

public class InstantReloadException extends Exception {
    public InstantReloadException(String s) {
        super(s);
    }
}
