package com.android.tools.fd.runtime;

public interface PatchesLoader {
    boolean load();
}
