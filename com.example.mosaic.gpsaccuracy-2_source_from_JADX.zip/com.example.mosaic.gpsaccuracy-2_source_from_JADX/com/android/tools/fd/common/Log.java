package com.android.tools.fd.common;

import java.util.logging.Level;

public class Log {
    public static Logging logging;

    public interface Logging {
        boolean isLoggable(Level level);

        void log(Level level, String str);

        void log(Level level, String str, Throwable th);
    }

    static {
        logging = null;
    }
}
