package com.example.mosaic.gpsaccuracy;

import com.android.tools.fd.runtime.IncrementalChange;
import com.android.tools.fd.runtime.InstantReloadException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

public class QueryString {
    public static volatile transient /* synthetic */ IncrementalChange $change;
    private StringBuilder query;

    QueryString(Object[] objArr, InstantReloadException instantReloadException) {
        switch (((String) objArr[0]).hashCode()) {
            case -1968665286:
            case -1901479806:
                this();
            default:
                throw new InstantReloadException(String.format("String switch could not find '%s' with hashcode %s in %s", new Object[]{(String) objArr[0], Integer.valueOf(((String) objArr[0]).hashCode()), "com/example/mosaic/gpsaccuracy/QueryString"}));
        }
    }

    public static /* synthetic */ Object access$super(QueryString queryString, String str, Object... objArr) {
        switch (str.hashCode()) {
            case -2128160755:
                return super.toString();
            case -1600833221:
                super.wait(((Number) objArr[0]).longValue(), ((Number) objArr[1]).intValue());
                return null;
            case -1554832987:
                super.finalize();
                return null;
            case -1166127280:
                super.notify();
                return null;
            case -1021472056:
                super.wait(((Number) objArr[0]).longValue());
                return null;
            case -712101345:
                super.notifyAll();
                return null;
            case 201261558:
                return super.getClass();
            case 244142972:
                super.wait();
                return null;
            case 1403628309:
                return new Integer(super.hashCode());
            case 1814730534:
                return new Boolean(super.equals(objArr[0]));
            case 2025021518:
                return super.clone();
            default:
                throw new InstantReloadException(String.format("String switch could not find '%s' with hashcode %s in %s", new Object[]{str, Integer.valueOf(str.hashCode()), "com/example/mosaic/gpsaccuracy/QueryString"}));
        }
    }

    private synchronized void encode(String name, String value) {
        IncrementalChange incrementalChange = $change;
        if (incrementalChange != null) {
            incrementalChange.access$dispatch("encode.(Ljava/lang/String;Ljava/lang/String;)V", this, name, value);
        } else {
            try {
                this.query.append(URLEncoder.encode(name, "UTF-8"));
                this.query.append('=');
                this.query.append(URLEncoder.encode(value, "UTF-8"));
            } catch (UnsupportedEncodingException e) {
                throw new RuntimeException("Broken VM does not support UTF-8");
            }
        }
    }

    public synchronized void add(String name, String value) {
        IncrementalChange incrementalChange = $change;
        if (incrementalChange != null) {
            incrementalChange.access$dispatch("add.(Ljava/lang/String;Ljava/lang/String;)V", this, name, value);
        } else {
            this.query.append('&');
            encode(name, value);
        }
    }

    public synchronized String getQuery() {
        String str;
        IncrementalChange incrementalChange = $change;
        if (incrementalChange != null) {
            str = (String) incrementalChange.access$dispatch("getQuery.()Ljava/lang/String;", this);
        } else {
            str = this.query.toString();
        }
        return str;
    }

    public String toString() {
        IncrementalChange incrementalChange = $change;
        if (incrementalChange == null) {
            return getQuery();
        }
        return (String) incrementalChange.access$dispatch("toString.()Ljava/lang/String;", this);
    }

    public QueryString() {
        IncrementalChange incrementalChange = $change;
        if (incrementalChange != null) {
            this((Object[]) incrementalChange.access$dispatch("init$args.([Ljava/lang/Object;)Ljava/lang/Object;", r2), null);
        }
        if (incrementalChange != null) {
            incrementalChange.access$dispatch("init$body.(Lcom/example/mosaic/gpsaccuracy/QueryString;)V", this);
            return;
        }
        this.query = new StringBuilder();
    }
}
