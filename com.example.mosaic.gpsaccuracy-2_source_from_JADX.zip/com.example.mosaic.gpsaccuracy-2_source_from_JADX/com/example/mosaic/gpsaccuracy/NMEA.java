package com.example.mosaic.gpsaccuracy;

import android.util.Log;
import com.android.tools.fd.runtime.IncrementalChange;
import com.android.tools.fd.runtime.InstantReloadException;
import java.util.HashMap;
import java.util.Map;

public class NMEA {
    public static volatile transient /* synthetic */ IncrementalChange $change;
    private static final Map<String, SentenceParser> sentenceParsers;
    public GPSPosition position;

    public class GPSPosition {
        public static volatile transient /* synthetic */ IncrementalChange $change;
        public float altitude;
        public float dir;
        public boolean fixed;
        public double hdop;
        public float lat;
        public float lon;
        public int quality;
        public int satelites;
        public final /* synthetic */ NMEA this$0;
        public double time;
        public float velocity;

        GPSPosition(Object[] objArr, InstantReloadException instantReloadException) {
            switch (((String) objArr[0]).hashCode()) {
                case -1968665286:
                case 1561705817:
                    this((NMEA) objArr[1]);
                default:
                    throw new InstantReloadException(String.format("String switch could not find '%s' with hashcode %s in %s", new Object[]{(String) objArr[0], Integer.valueOf(((String) objArr[0]).hashCode()), "com/example/mosaic/gpsaccuracy/NMEA$GPSPosition"}));
            }
        }

        public static /* synthetic */ Object access$super(GPSPosition gPSPosition, String str, Object... objArr) {
            switch (str.hashCode()) {
                case -2128160755:
                    return super.toString();
                case -1600833221:
                    super.wait(((Number) objArr[0]).longValue(), ((Number) objArr[1]).intValue());
                    return null;
                case -1554832987:
                    super.finalize();
                    return null;
                case -1166127280:
                    super.notify();
                    return null;
                case -1021472056:
                    super.wait(((Number) objArr[0]).longValue());
                    return null;
                case -712101345:
                    super.notifyAll();
                    return null;
                case 201261558:
                    return super.getClass();
                case 244142972:
                    super.wait();
                    return null;
                case 1403628309:
                    return new Integer(super.hashCode());
                case 1814730534:
                    return new Boolean(super.equals(objArr[0]));
                case 2025021518:
                    return super.clone();
                default:
                    throw new InstantReloadException(String.format("String switch could not find '%s' with hashcode %s in %s", new Object[]{str, Integer.valueOf(str.hashCode()), "com/example/mosaic/gpsaccuracy/NMEA$GPSPosition"}));
            }
        }

        public String toString() {
            IncrementalChange incrementalChange = $change;
            if (incrementalChange != null) {
                return (String) incrementalChange.access$dispatch("toString.()Ljava/lang/String;", this);
            }
            return String.format("POSITION: lat: %f, lon: %f, time: %f, Q: %d, dir: %f, alt: %f, vel: %f", new Object[]{Float.valueOf(this.lat), Float.valueOf(this.lon), Double.valueOf(this.time), Integer.valueOf(this.quality), Float.valueOf(this.dir), Float.valueOf(this.altitude), Float.valueOf(this.velocity)});
        }

        public void updatefix() {
            boolean z = true;
            IncrementalChange incrementalChange = $change;
            if (incrementalChange != null) {
                incrementalChange.access$dispatch("updatefix.()V", this);
                return;
            }
            if (this.quality <= 0) {
                z = false;
            }
            this.fixed = z;
        }

        public GPSPosition(NMEA this$0) {
            IncrementalChange incrementalChange = $change;
            this.this$0 = this$0;
            if (incrementalChange != null) {
                Object[] objArr = new Object[]{objArr, this$0};
                this$0 = objArr[1];
                this((Object[]) incrementalChange.access$dispatch("init$args.([Ljava/lang/Object;Lcom/example/mosaic/gpsaccuracy/NMEA;)Ljava/lang/Object;", objArr), null);
            }
            if (incrementalChange != null) {
                incrementalChange.access$dispatch("init$body.(Lcom/example/mosaic/gpsaccuracy/NMEA$GPSPosition;Lcom/example/mosaic/gpsaccuracy/NMEA;)V", this, this$0);
                return;
            }
            this.time = 0.0d;
            this.lat = 0.0f;
            this.lon = 0.0f;
            this.fixed = false;
            this.quality = 0;
            this.dir = 0.0f;
            this.altitude = 0.0f;
            this.velocity = 0.0f;
            this.satelites = 0;
            this.hdop = 0.0d;
        }
    }

    interface SentenceParser {
        boolean parse(String[] strArr, GPSPosition gPSPosition);
    }

    class GPGGA implements SentenceParser {
        public static volatile transient /* synthetic */ IncrementalChange $change;
        public final /* synthetic */ NMEA this$0;

        GPGGA(Object[] objArr, InstantReloadException instantReloadException) {
            switch (((String) objArr[0]).hashCode()) {
                case -1968665286:
                case 369376564:
                    this((NMEA) objArr[1]);
                default:
                    throw new InstantReloadException(String.format("String switch could not find '%s' with hashcode %s in %s", new Object[]{(String) objArr[0], Integer.valueOf(((String) objArr[0]).hashCode()), "com/example/mosaic/gpsaccuracy/NMEA$GPGGA"}));
            }
        }

        public static /* synthetic */ Object access$super(GPGGA gpgga, String str, Object... objArr) {
            switch (str.hashCode()) {
                case -2128160755:
                    return super.toString();
                case -1600833221:
                    super.wait(((Number) objArr[0]).longValue(), ((Number) objArr[1]).intValue());
                    return null;
                case -1554832987:
                    super.finalize();
                    return null;
                case -1166127280:
                    super.notify();
                    return null;
                case -1021472056:
                    super.wait(((Number) objArr[0]).longValue());
                    return null;
                case -712101345:
                    super.notifyAll();
                    return null;
                case 201261558:
                    return super.getClass();
                case 244142972:
                    super.wait();
                    return null;
                case 1403628309:
                    return new Integer(super.hashCode());
                case 1814730534:
                    return new Boolean(super.equals(objArr[0]));
                case 2025021518:
                    return super.clone();
                default:
                    throw new InstantReloadException(String.format("String switch could not find '%s' with hashcode %s in %s", new Object[]{str, Integer.valueOf(str.hashCode()), "com/example/mosaic/gpsaccuracy/NMEA$GPGGA"}));
            }
        }

        public boolean parse(String[] tokens, GPSPosition position) {
            IncrementalChange incrementalChange = $change;
            if (incrementalChange != null) {
                return ((Boolean) incrementalChange.access$dispatch("parse.([Ljava/lang/String;Lcom/example/mosaic/gpsaccuracy/NMEA$GPSPosition;)Z", this, tokens, position)).booleanValue();
            }
            try {
                position.time = tokens[1] == null ? position.time : (double) Float.parseFloat(tokens[1]);
                position.lat = tokens[2] == null ? position.lat : NMEA.Latitude2Decimal(tokens[2], tokens[3]);
                float Longitude2Decimal = (tokens[4] == null || tokens[5] == null) ? position.lon : NMEA.Longitude2Decimal(tokens[4], tokens[5]);
                position.lon = Longitude2Decimal;
                position.quality = tokens[6] == null ? position.quality : Integer.parseInt(tokens[6]);
                position.altitude = tokens[9] == null ? position.altitude : Float.parseFloat(tokens[9]);
                return true;
            } catch (NumberFormatException e) {
                Log.e("NMEA", tokens.toString());
                return true;
            }
        }

        public GPGGA(NMEA this$0) {
            IncrementalChange incrementalChange = $change;
            this.this$0 = this$0;
            if (incrementalChange != null) {
                Object[] objArr = new Object[]{objArr, this$0};
                this$0 = objArr[1];
                this((Object[]) incrementalChange.access$dispatch("init$args.([Ljava/lang/Object;Lcom/example/mosaic/gpsaccuracy/NMEA;)Ljava/lang/Object;", objArr), null);
            }
            if (incrementalChange != null) {
                incrementalChange.access$dispatch("init$body.(Lcom/example/mosaic/gpsaccuracy/NMEA$GPGGA;Lcom/example/mosaic/gpsaccuracy/NMEA;)V", this, this$0);
            }
        }
    }

    class GPGGL implements SentenceParser {
        public static volatile transient /* synthetic */ IncrementalChange $change;
        public final /* synthetic */ NMEA this$0;

        GPGGL(Object[] objArr, InstantReloadException instantReloadException) {
            switch (((String) objArr[0]).hashCode()) {
                case -1968665286:
                case 1734182281:
                    this((NMEA) objArr[1]);
                default:
                    throw new InstantReloadException(String.format("String switch could not find '%s' with hashcode %s in %s", new Object[]{(String) objArr[0], Integer.valueOf(((String) objArr[0]).hashCode()), "com/example/mosaic/gpsaccuracy/NMEA$GPGGL"}));
            }
        }

        public static /* synthetic */ Object access$super(GPGGL gpggl, String str, Object... objArr) {
            switch (str.hashCode()) {
                case -2128160755:
                    return super.toString();
                case -1600833221:
                    super.wait(((Number) objArr[0]).longValue(), ((Number) objArr[1]).intValue());
                    return null;
                case -1554832987:
                    super.finalize();
                    return null;
                case -1166127280:
                    super.notify();
                    return null;
                case -1021472056:
                    super.wait(((Number) objArr[0]).longValue());
                    return null;
                case -712101345:
                    super.notifyAll();
                    return null;
                case 201261558:
                    return super.getClass();
                case 244142972:
                    super.wait();
                    return null;
                case 1403628309:
                    return new Integer(super.hashCode());
                case 1814730534:
                    return new Boolean(super.equals(objArr[0]));
                case 2025021518:
                    return super.clone();
                default:
                    throw new InstantReloadException(String.format("String switch could not find '%s' with hashcode %s in %s", new Object[]{str, Integer.valueOf(str.hashCode()), "com/example/mosaic/gpsaccuracy/NMEA$GPGGL"}));
            }
        }

        public boolean parse(String[] tokens, GPSPosition position) {
            IncrementalChange incrementalChange = $change;
            if (incrementalChange != null) {
                return ((Boolean) incrementalChange.access$dispatch("parse.([Ljava/lang/String;Lcom/example/mosaic/gpsaccuracy/NMEA$GPSPosition;)Z", this, tokens, position)).booleanValue();
            }
            try {
                float Latitude2Decimal = (tokens[1] == null || tokens[2] == null) ? position.lat : NMEA.Latitude2Decimal(tokens[1], tokens[2]);
                position.lat = Latitude2Decimal;
                Latitude2Decimal = (tokens[3] == null || tokens[4] == null) ? position.lon : NMEA.Longitude2Decimal(tokens[3], tokens[4]);
                position.lon = Latitude2Decimal;
                position.time = tokens[5] == null ? position.time : (double) Float.parseFloat(tokens[5]);
                return true;
            } catch (NumberFormatException e) {
                Log.e("NMEA", e.toString());
                return true;
            }
        }

        public GPGGL(NMEA this$0) {
            IncrementalChange incrementalChange = $change;
            this.this$0 = this$0;
            if (incrementalChange != null) {
                Object[] objArr = new Object[]{objArr, this$0};
                this$0 = objArr[1];
                this((Object[]) incrementalChange.access$dispatch("init$args.([Ljava/lang/Object;Lcom/example/mosaic/gpsaccuracy/NMEA;)Ljava/lang/Object;", objArr), null);
            }
            if (incrementalChange != null) {
                incrementalChange.access$dispatch("init$body.(Lcom/example/mosaic/gpsaccuracy/NMEA$GPGGL;Lcom/example/mosaic/gpsaccuracy/NMEA;)V", this, this$0);
            }
        }
    }

    class GPGSA implements SentenceParser {
        public static volatile transient /* synthetic */ IncrementalChange $change;
        public final /* synthetic */ NMEA this$0;

        GPGSA(Object[] objArr, InstantReloadException instantReloadException) {
            switch (((String) objArr[0]).hashCode()) {
                case -1968665286:
                case -720015808:
                    this((NMEA) objArr[1]);
                default:
                    throw new InstantReloadException(String.format("String switch could not find '%s' with hashcode %s in %s", new Object[]{(String) objArr[0], Integer.valueOf(((String) objArr[0]).hashCode()), "com/example/mosaic/gpsaccuracy/NMEA$GPGSA"}));
            }
        }

        public static /* synthetic */ Object access$super(GPGSA gpgsa, String str, Object... objArr) {
            switch (str.hashCode()) {
                case -2128160755:
                    return super.toString();
                case -1600833221:
                    super.wait(((Number) objArr[0]).longValue(), ((Number) objArr[1]).intValue());
                    return null;
                case -1554832987:
                    super.finalize();
                    return null;
                case -1166127280:
                    super.notify();
                    return null;
                case -1021472056:
                    super.wait(((Number) objArr[0]).longValue());
                    return null;
                case -712101345:
                    super.notifyAll();
                    return null;
                case 201261558:
                    return super.getClass();
                case 244142972:
                    super.wait();
                    return null;
                case 1403628309:
                    return new Integer(super.hashCode());
                case 1814730534:
                    return new Boolean(super.equals(objArr[0]));
                case 2025021518:
                    return super.clone();
                default:
                    throw new InstantReloadException(String.format("String switch could not find '%s' with hashcode %s in %s", new Object[]{str, Integer.valueOf(str.hashCode()), "com/example/mosaic/gpsaccuracy/NMEA$GPGSA"}));
            }
        }

        public boolean parse(String[] tokens, GPSPosition position) {
            IncrementalChange incrementalChange = $change;
            if (incrementalChange != null) {
                return ((Boolean) incrementalChange.access$dispatch("parse.([Ljava/lang/String;Lcom/example/mosaic/gpsaccuracy/NMEA$GPSPosition;)Z", this, tokens, position)).booleanValue();
            }
            double parseDouble = (tokens[16] == null || tokens[16].length() < 1) ? 99.99d : Double.parseDouble(tokens[16]);
            position.hdop = parseDouble;
            return true;
        }

        public GPGSA(NMEA this$0) {
            IncrementalChange incrementalChange = $change;
            this.this$0 = this$0;
            if (incrementalChange != null) {
                Object[] objArr = new Object[]{objArr, this$0};
                this$0 = objArr[1];
                this((Object[]) incrementalChange.access$dispatch("init$args.([Ljava/lang/Object;Lcom/example/mosaic/gpsaccuracy/NMEA;)Ljava/lang/Object;", objArr), null);
            }
            if (incrementalChange != null) {
                incrementalChange.access$dispatch("init$body.(Lcom/example/mosaic/gpsaccuracy/NMEA$GPGSA;Lcom/example/mosaic/gpsaccuracy/NMEA;)V", this, this$0);
            }
        }
    }

    class GPGSV implements SentenceParser {
        public static volatile transient /* synthetic */ IncrementalChange $change;
        public final /* synthetic */ NMEA this$0;

        GPGSV(Object[] objArr, InstantReloadException instantReloadException) {
            switch (((String) objArr[0]).hashCode()) {
                case -1968665286:
                case 1885522379:
                    this((NMEA) objArr[1]);
                default:
                    throw new InstantReloadException(String.format("String switch could not find '%s' with hashcode %s in %s", new Object[]{(String) objArr[0], Integer.valueOf(((String) objArr[0]).hashCode()), "com/example/mosaic/gpsaccuracy/NMEA$GPGSV"}));
            }
        }

        public static /* synthetic */ Object access$super(GPGSV gpgsv, String str, Object... objArr) {
            switch (str.hashCode()) {
                case -2128160755:
                    return super.toString();
                case -1600833221:
                    super.wait(((Number) objArr[0]).longValue(), ((Number) objArr[1]).intValue());
                    return null;
                case -1554832987:
                    super.finalize();
                    return null;
                case -1166127280:
                    super.notify();
                    return null;
                case -1021472056:
                    super.wait(((Number) objArr[0]).longValue());
                    return null;
                case -712101345:
                    super.notifyAll();
                    return null;
                case 201261558:
                    return super.getClass();
                case 244142972:
                    super.wait();
                    return null;
                case 1403628309:
                    return new Integer(super.hashCode());
                case 1814730534:
                    return new Boolean(super.equals(objArr[0]));
                case 2025021518:
                    return super.clone();
                default:
                    throw new InstantReloadException(String.format("String switch could not find '%s' with hashcode %s in %s", new Object[]{str, Integer.valueOf(str.hashCode()), "com/example/mosaic/gpsaccuracy/NMEA$GPGSV"}));
            }
        }

        public boolean parse(String[] tokens, GPSPosition position) {
            IncrementalChange incrementalChange = $change;
            if (incrementalChange != null) {
                return ((Boolean) incrementalChange.access$dispatch("parse.([Ljava/lang/String;Lcom/example/mosaic/gpsaccuracy/NMEA$GPSPosition;)Z", this, tokens, position)).booleanValue();
            }
            position.satelites = Integer.parseInt(tokens[3]);
            return true;
        }

        public GPGSV(NMEA this$0) {
            IncrementalChange incrementalChange = $change;
            this.this$0 = this$0;
            if (incrementalChange != null) {
                Object[] objArr = new Object[]{objArr, this$0};
                this$0 = objArr[1];
                this((Object[]) incrementalChange.access$dispatch("init$args.([Ljava/lang/Object;Lcom/example/mosaic/gpsaccuracy/NMEA;)Ljava/lang/Object;", objArr), null);
            }
            if (incrementalChange != null) {
                incrementalChange.access$dispatch("init$body.(Lcom/example/mosaic/gpsaccuracy/NMEA$GPGSV;Lcom/example/mosaic/gpsaccuracy/NMEA;)V", this, this$0);
            }
        }
    }

    class GPRMC implements SentenceParser {
        public static volatile transient /* synthetic */ IncrementalChange $change;
        public final /* synthetic */ NMEA this$0;

        GPRMC(Object[] objArr, InstantReloadException instantReloadException) {
            switch (((String) objArr[0]).hashCode()) {
                case -1968665286:
                case -461388019:
                    this((NMEA) objArr[1]);
                default:
                    throw new InstantReloadException(String.format("String switch could not find '%s' with hashcode %s in %s", new Object[]{(String) objArr[0], Integer.valueOf(((String) objArr[0]).hashCode()), "com/example/mosaic/gpsaccuracy/NMEA$GPRMC"}));
            }
        }

        public static /* synthetic */ Object access$super(GPRMC gprmc, String str, Object... objArr) {
            switch (str.hashCode()) {
                case -2128160755:
                    return super.toString();
                case -1600833221:
                    super.wait(((Number) objArr[0]).longValue(), ((Number) objArr[1]).intValue());
                    return null;
                case -1554832987:
                    super.finalize();
                    return null;
                case -1166127280:
                    super.notify();
                    return null;
                case -1021472056:
                    super.wait(((Number) objArr[0]).longValue());
                    return null;
                case -712101345:
                    super.notifyAll();
                    return null;
                case 201261558:
                    return super.getClass();
                case 244142972:
                    super.wait();
                    return null;
                case 1403628309:
                    return new Integer(super.hashCode());
                case 1814730534:
                    return new Boolean(super.equals(objArr[0]));
                case 2025021518:
                    return super.clone();
                default:
                    throw new InstantReloadException(String.format("String switch could not find '%s' with hashcode %s in %s", new Object[]{str, Integer.valueOf(str.hashCode()), "com/example/mosaic/gpsaccuracy/NMEA$GPRMC"}));
            }
        }

        public boolean parse(String[] tokens, GPSPosition position) {
            IncrementalChange incrementalChange = $change;
            if (incrementalChange != null) {
                return ((Boolean) incrementalChange.access$dispatch("parse.([Ljava/lang/String;Lcom/example/mosaic/gpsaccuracy/NMEA$GPSPosition;)Z", this, tokens, position)).booleanValue();
            }
            try {
                position.time = tokens[1] == null ? position.time : (double) Float.parseFloat(tokens[1]);
                float Latitude2Decimal = (tokens[3] == null || tokens[4] == null) ? position.lat : NMEA.Latitude2Decimal(tokens[3], tokens[4]);
                position.lat = Latitude2Decimal;
                Latitude2Decimal = (tokens[5] == null || tokens[6] == null) ? position.lon : NMEA.Longitude2Decimal(tokens[5], tokens[6]);
                position.lon = Latitude2Decimal;
                position.velocity = tokens[7] == null ? position.velocity : Float.parseFloat(tokens[7]);
                position.dir = tokens[8] == null ? position.dir : Float.parseFloat(tokens[8]);
                return true;
            } catch (NumberFormatException nfe) {
                Log.e("Number Format Exeption", nfe.toString());
                return true;
            }
        }

        public GPRMC(NMEA this$0) {
            IncrementalChange incrementalChange = $change;
            this.this$0 = this$0;
            if (incrementalChange != null) {
                Object[] objArr = new Object[]{objArr, this$0};
                this$0 = objArr[1];
                this((Object[]) incrementalChange.access$dispatch("init$args.([Ljava/lang/Object;Lcom/example/mosaic/gpsaccuracy/NMEA;)Ljava/lang/Object;", objArr), null);
            }
            if (incrementalChange != null) {
                incrementalChange.access$dispatch("init$body.(Lcom/example/mosaic/gpsaccuracy/NMEA$GPRMC;Lcom/example/mosaic/gpsaccuracy/NMEA;)V", this, this$0);
            }
        }
    }

    class GPRMZ implements SentenceParser {
        public static volatile transient /* synthetic */ IncrementalChange $change;
        public final /* synthetic */ NMEA this$0;

        GPRMZ(Object[] objArr, InstantReloadException instantReloadException) {
            switch (((String) objArr[0]).hashCode()) {
                case -1968665286:
                case -1902670634:
                    this((NMEA) objArr[1]);
                default:
                    throw new InstantReloadException(String.format("String switch could not find '%s' with hashcode %s in %s", new Object[]{(String) objArr[0], Integer.valueOf(((String) objArr[0]).hashCode()), "com/example/mosaic/gpsaccuracy/NMEA$GPRMZ"}));
            }
        }

        public static /* synthetic */ Object access$super(GPRMZ gprmz, String str, Object... objArr) {
            switch (str.hashCode()) {
                case -2128160755:
                    return super.toString();
                case -1600833221:
                    super.wait(((Number) objArr[0]).longValue(), ((Number) objArr[1]).intValue());
                    return null;
                case -1554832987:
                    super.finalize();
                    return null;
                case -1166127280:
                    super.notify();
                    return null;
                case -1021472056:
                    super.wait(((Number) objArr[0]).longValue());
                    return null;
                case -712101345:
                    super.notifyAll();
                    return null;
                case 201261558:
                    return super.getClass();
                case 244142972:
                    super.wait();
                    return null;
                case 1403628309:
                    return new Integer(super.hashCode());
                case 1814730534:
                    return new Boolean(super.equals(objArr[0]));
                case 2025021518:
                    return super.clone();
                default:
                    throw new InstantReloadException(String.format("String switch could not find '%s' with hashcode %s in %s", new Object[]{str, Integer.valueOf(str.hashCode()), "com/example/mosaic/gpsaccuracy/NMEA$GPRMZ"}));
            }
        }

        public boolean parse(String[] tokens, GPSPosition position) {
            IncrementalChange incrementalChange = $change;
            if (incrementalChange != null) {
                return ((Boolean) incrementalChange.access$dispatch("parse.([Ljava/lang/String;Lcom/example/mosaic/gpsaccuracy/NMEA$GPSPosition;)Z", this, tokens, position)).booleanValue();
            }
            int satelites = 0;
            position.altitude = Float.parseFloat(tokens[1]);
            for (int i = 3; i < 15; i++) {
                int i2;
                if (tokens[i] == null) {
                    i2 = 0;
                } else {
                    i2 = 1;
                }
                satelites += i2;
            }
            position.satelites = satelites;
            return true;
        }

        public GPRMZ(NMEA this$0) {
            IncrementalChange incrementalChange = $change;
            this.this$0 = this$0;
            if (incrementalChange != null) {
                Object[] objArr = new Object[]{objArr, this$0};
                this$0 = objArr[1];
                this((Object[]) incrementalChange.access$dispatch("init$args.([Ljava/lang/Object;Lcom/example/mosaic/gpsaccuracy/NMEA;)Ljava/lang/Object;", objArr), null);
            }
            if (incrementalChange != null) {
                incrementalChange.access$dispatch("init$body.(Lcom/example/mosaic/gpsaccuracy/NMEA$GPRMZ;Lcom/example/mosaic/gpsaccuracy/NMEA;)V", this, this$0);
            }
        }
    }

    class GPVTG implements SentenceParser {
        public static volatile transient /* synthetic */ IncrementalChange $change;
        public final /* synthetic */ NMEA this$0;

        GPVTG(Object[] objArr, InstantReloadException instantReloadException) {
            switch (((String) objArr[0]).hashCode()) {
                case -1968665286:
                case 1385187404:
                    this((NMEA) objArr[1]);
                default:
                    throw new InstantReloadException(String.format("String switch could not find '%s' with hashcode %s in %s", new Object[]{(String) objArr[0], Integer.valueOf(((String) objArr[0]).hashCode()), "com/example/mosaic/gpsaccuracy/NMEA$GPVTG"}));
            }
        }

        public static /* synthetic */ Object access$super(GPVTG gpvtg, String str, Object... objArr) {
            switch (str.hashCode()) {
                case -2128160755:
                    return super.toString();
                case -1600833221:
                    super.wait(((Number) objArr[0]).longValue(), ((Number) objArr[1]).intValue());
                    return null;
                case -1554832987:
                    super.finalize();
                    return null;
                case -1166127280:
                    super.notify();
                    return null;
                case -1021472056:
                    super.wait(((Number) objArr[0]).longValue());
                    return null;
                case -712101345:
                    super.notifyAll();
                    return null;
                case 201261558:
                    return super.getClass();
                case 244142972:
                    super.wait();
                    return null;
                case 1403628309:
                    return new Integer(super.hashCode());
                case 1814730534:
                    return new Boolean(super.equals(objArr[0]));
                case 2025021518:
                    return super.clone();
                default:
                    throw new InstantReloadException(String.format("String switch could not find '%s' with hashcode %s in %s", new Object[]{str, Integer.valueOf(str.hashCode()), "com/example/mosaic/gpsaccuracy/NMEA$GPVTG"}));
            }
        }

        public boolean parse(String[] tokens, GPSPosition position) {
            IncrementalChange incrementalChange = $change;
            if (incrementalChange == null) {
                return true;
            }
            return ((Boolean) incrementalChange.access$dispatch("parse.([Ljava/lang/String;Lcom/example/mosaic/gpsaccuracy/NMEA$GPSPosition;)Z", this, tokens, position)).booleanValue();
        }

        public GPVTG(NMEA this$0) {
            IncrementalChange incrementalChange = $change;
            this.this$0 = this$0;
            if (incrementalChange != null) {
                Object[] objArr = new Object[]{objArr, this$0};
                this$0 = objArr[1];
                this((Object[]) incrementalChange.access$dispatch("init$args.([Ljava/lang/Object;Lcom/example/mosaic/gpsaccuracy/NMEA;)Ljava/lang/Object;", objArr), null);
            }
            if (incrementalChange != null) {
                incrementalChange.access$dispatch("init$body.(Lcom/example/mosaic/gpsaccuracy/NMEA$GPVTG;Lcom/example/mosaic/gpsaccuracy/NMEA;)V", this, this$0);
            }
        }
    }

    NMEA(Object[] objArr, InstantReloadException instantReloadException) {
        switch (((String) objArr[0]).hashCode()) {
            case -1968665286:
            case 8855104:
                this();
            default:
                throw new InstantReloadException(String.format("String switch could not find '%s' with hashcode %s in %s", new Object[]{(String) objArr[0], Integer.valueOf(((String) objArr[0]).hashCode()), "com/example/mosaic/gpsaccuracy/NMEA"}));
        }
    }

    public static float Latitude2Decimal(String lat, String NS) {
        IncrementalChange incrementalChange = $change;
        if (incrementalChange != null) {
            return ((Number) incrementalChange.access$dispatch("Latitude2Decimal.(Ljava/lang/String;Ljava/lang/String;)F", lat, NS)).floatValue();
        }
        if (lat == null || lat.length() < 3) {
            lat = "0.00";
        }
        float med = (Float.parseFloat(lat.substring(2)) / 60.0f) + Float.parseFloat(lat.substring(0, 2));
        if (NS.startsWith("S")) {
            return -med;
        }
        return med;
    }

    public static float Longitude2Decimal(String lon, String WE) {
        IncrementalChange incrementalChange = $change;
        if (incrementalChange != null) {
            return ((Number) incrementalChange.access$dispatch("Longitude2Decimal.(Ljava/lang/String;Ljava/lang/String;)F", lon, WE)).floatValue();
        }
        if (lon == null || lon.length() < 2) {
            lon = "0.0";
        }
        float med = (Float.parseFloat(lon.substring(3)) / 60.0f) + Float.parseFloat(lon.substring(0, 3));
        if (WE.startsWith("W")) {
            return -med;
        }
        return med;
    }

    public static /* synthetic */ Object access$super(NMEA nmea, String str, Object... objArr) {
        switch (str.hashCode()) {
            case -2128160755:
                return super.toString();
            case -1600833221:
                super.wait(((Number) objArr[0]).longValue(), ((Number) objArr[1]).intValue());
                return null;
            case -1554832987:
                super.finalize();
                return null;
            case -1166127280:
                super.notify();
                return null;
            case -1021472056:
                super.wait(((Number) objArr[0]).longValue());
                return null;
            case -712101345:
                super.notifyAll();
                return null;
            case 201261558:
                return super.getClass();
            case 244142972:
                super.wait();
                return null;
            case 1403628309:
                return new Integer(super.hashCode());
            case 1814730534:
                return new Boolean(super.equals(objArr[0]));
            case 2025021518:
                return super.clone();
            default:
                throw new InstantReloadException(String.format("String switch could not find '%s' with hashcode %s in %s", new Object[]{str, Integer.valueOf(str.hashCode()), "com/example/mosaic/gpsaccuracy/NMEA"}));
        }
    }

    public GPSPosition parse(String line) {
        IncrementalChange incrementalChange = $change;
        if (incrementalChange != null) {
            return (GPSPosition) incrementalChange.access$dispatch("parse.(Ljava/lang/String;)Lcom/example/mosaic/gpsaccuracy/NMEA$GPSPosition;", this, line);
        }
        if (line.startsWith("$")) {
            String[] tokens = line.substring(1).split(",");
            String type = tokens[0];
            if (sentenceParsers.containsKey(type)) {
                ((SentenceParser) sentenceParsers.get(type)).parse(tokens, this.position);
            }
            this.position.updatefix();
        }
        return this.position;
    }

    static {
        sentenceParsers = new HashMap();
    }

    public NMEA() {
        IncrementalChange incrementalChange = $change;
        if (incrementalChange != null) {
            this((Object[]) incrementalChange.access$dispatch("init$args.([Ljava/lang/Object;)Ljava/lang/Object;", r2), null);
        }
        if (incrementalChange != null) {
            incrementalChange.access$dispatch("init$body.(Lcom/example/mosaic/gpsaccuracy/NMEA;)V", this);
            return;
        }
        this.position = new GPSPosition(this);
        sentenceParsers.put("GPGGA", new GPGGA(this));
        sentenceParsers.put("GPGGL", new GPGGL(this));
        sentenceParsers.put("GPRMC", new GPRMC(this));
        sentenceParsers.put("GPRMZ", new GPRMZ(this));
        sentenceParsers.put("GPGSV", new GPGSV(this));
        sentenceParsers.put("GPVTG", new GPVTG(this));
        sentenceParsers.put("GPGSA", new GPGSA(this));
    }
}
