package com.example.mosaic.gpsaccuracy;

import com.android.tools.fd.runtime.IncrementalChange;
import com.android.tools.fd.runtime.InstantReloadException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.UnknownHostException;

public class FormPoster {
    public static volatile transient /* synthetic */ IncrementalChange $change;
    private QueryString query;
    private URL url;

    FormPoster(Object[] objArr, InstantReloadException instantReloadException) {
        switch (((String) objArr[0]).hashCode()) {
            case -1968665286:
            case -1069731723:
                this((URL) objArr[1]);
            default:
                throw new InstantReloadException(String.format("String switch could not find '%s' with hashcode %s in %s", new Object[]{(String) objArr[0], Integer.valueOf(((String) objArr[0]).hashCode()), "com/example/mosaic/gpsaccuracy/FormPoster"}));
        }
    }

    public static /* synthetic */ Object access$super(FormPoster formPoster, String str, Object... objArr) {
        switch (str.hashCode()) {
            case -2128160755:
                return super.toString();
            case -1600833221:
                super.wait(((Number) objArr[0]).longValue(), ((Number) objArr[1]).intValue());
                return null;
            case -1554832987:
                super.finalize();
                return null;
            case -1166127280:
                super.notify();
                return null;
            case -1021472056:
                super.wait(((Number) objArr[0]).longValue());
                return null;
            case -712101345:
                super.notifyAll();
                return null;
            case 201261558:
                return super.getClass();
            case 244142972:
                super.wait();
                return null;
            case 1403628309:
                return new Integer(super.hashCode());
            case 1814730534:
                return new Boolean(super.equals(objArr[0]));
            case 2025021518:
                return super.clone();
            default:
                throw new InstantReloadException(String.format("String switch could not find '%s' with hashcode %s in %s", new Object[]{str, Integer.valueOf(str.hashCode()), "com/example/mosaic/gpsaccuracy/FormPoster"}));
        }
    }

    public void add(String name, String value) {
        IncrementalChange incrementalChange = $change;
        if (incrementalChange != null) {
            incrementalChange.access$dispatch("add.(Ljava/lang/String;Ljava/lang/String;)V", this, name, value);
            return;
        }
        this.query.add(name, value);
    }

    public URL getURL() {
        IncrementalChange incrementalChange = $change;
        if (incrementalChange == null) {
            return this.url;
        }
        return (URL) incrementalChange.access$dispatch("getURL.()Ljava/net/URL;", this);
    }

    public InputStream post() throws IOException {
        IncrementalChange incrementalChange = $change;
        if (incrementalChange != null) {
            return (InputStream) incrementalChange.access$dispatch("post.()Ljava/io/InputStream;", this);
        }
        HttpURLConnection uc = (HttpURLConnection) this.url.openConnection();
        uc.setDoOutput(true);
        try {
            OutputStreamWriter out = new OutputStreamWriter(uc.getOutputStream(), "UTF-8");
            out.write(this.query.toString());
            out.write("\n");
            out.flush();
        } catch (UnknownHostException e) {
        }
        return uc.getInputStream();
    }

    public FormPoster(URL url) {
        IncrementalChange incrementalChange = $change;
        if (incrementalChange != null) {
            Object[] objArr = new Object[]{objArr, url};
            url = objArr[1];
            this((Object[]) incrementalChange.access$dispatch("init$args.([Ljava/lang/Object;Ljava/net/URL;)Ljava/lang/Object;", objArr), null);
        }
        if (incrementalChange != null) {
            incrementalChange.access$dispatch("init$body.(Lcom/example/mosaic/gpsaccuracy/FormPoster;Ljava/net/URL;)V", this, url);
            return;
        }
        this.query = new QueryString();
        if (url.getProtocol().toLowerCase().startsWith("http")) {
            this.url = url;
            return;
        }
        throw new IllegalArgumentException("Posting only works for http URLs");
    }
}
